package Principal_PruebaFinal;

import Clases.EmpleadoOficina;
import Clases.EmpleadoProduccion;
import Dao.DEmpleadoOf;
import Dao.DEmpleadoProduccion;

/**
 *
 * @author giancarlos 
 */
public class Principal_PruebaFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        EmpleadoOficina empleado1 = new EmpleadoOficina(001, "Jan", "Prado", 1000.10, 01);
        EmpleadoOficina empleado2 = new EmpleadoOficina(002, "Jason", "Esquivel", 2000.20, 02);
        EmpleadoOficina empleado3 = new EmpleadoOficina(003, "Leoncio", "Pavon", 3000.30, 03);

        DEmpleadoOf Empleados_Oficina = new DEmpleadoOf();

        Empleados_Oficina.mostrarRegistros(empleado1);
        Empleados_Oficina.mostrarRegistros(empleado2);
        Empleados_Oficina.mostrarRegistros(empleado3);

        EmpleadoProduccion empleado01 = new EmpleadoProduccion(120, "Norman", "Josue", 10000.00, 10, 2000);
        EmpleadoProduccion empleado02 = new EmpleadoProduccion(321, "Carlos", "Alcides", 20000.00, 20, 3000);
        EmpleadoProduccion empleado03 = new EmpleadoProduccion(129, "Yizark", "Al", 30000.00, 30, 34000);

        DEmpleadoProduccion Empleados_Produccion = new DEmpleadoProduccion();

        Empleados_Produccion.mostrarRegistros(empleado01);
        Empleados_Produccion.mostrarRegistros(empleado02);
        Empleados_Produccion.mostrarRegistros(empleado03);
    }
}
