package Interfaces;

import java.util.Objects;

/**
 * @author giancarlos 
 * @version 1.0
 * @created 30-nov.-2021 20:22:00
 */
public interface IOperaciones {

    /**
     *
     * @param Object
     */
    public void agregarRegistro(Object registro);

    public Object mostrarRegistros(Object registro);

}
