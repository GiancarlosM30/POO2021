package Dao;

import Clases.EmpleadoOficina;
import Interfaces.IOperaciones;
import java.util.ArrayList;

/**
 *
 * @author giancarlos 
 */
public class DEmpleadoOf implements IOperaciones {

    ArrayList<EmpleadoOficina> lista = new ArrayList();

    @Override
    public void agregarRegistro(Object registro) {
        lista.add((EmpleadoOficina) registro);
    }

    @Override
    public Object mostrarRegistros(Object registro) {
        System.out.println(registro);
        System.out.println();
        return null;

    }

}
