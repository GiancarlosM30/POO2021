package Dao;

import Clases.EmpleadoProduccion;
import Interfaces.IOperaciones;
import java.util.ArrayList;

/**
 *
 * @authorc giancarlos 
 */
public class DEmpleadoProduccion implements IOperaciones {

    ArrayList<EmpleadoProduccion> lista = new ArrayList();

    @Override
    public void agregarRegistro(Object registro) {
        lista.add((EmpleadoProduccion) registro);
    }

    @Override
    public Object mostrarRegistros(Object registro) {
        System.out.println(registro);
        System.out.println();
        return null;
    }

}
